// import { createStore, combineReducers } from "redux";
import { configureStore } from "@reduxjs/toolkit";
import counterReducer from "./counter.js";
import authReducer from "./auth.js";

// const store = createStore(counterSlice.reducer);
const store = configureStore({
  //   reducer: counterSlice.reducer,
  reducer: { counter: counterReducer, auth: authReducer },
});

export default store;
