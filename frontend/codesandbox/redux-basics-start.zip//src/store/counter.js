import { createSlice } from "@reduxjs/toolkit";

//1. 定义初始状态
const initialCounterState = { counter: 0, showCounter: true };

//2. 创建 Reducer
// const counterReducer = (state = initialState, action) => {
//   switch (action.type) {
//     case "increment":
//       return {
//         ...state,
//         counter: state.counter + 1,
//         // showCounter: state.showCounter
//       };
//     case "decrement":
//       return {
//         ...state,
//         counter: state.counter - 1,
//         // showCounter: state.showCounter
//       };
//     case "increase":
//       return {
//         counter: state.counter + action.amount,
//         showCounter: state.showCounter,
//       };
//     case "toggle":
//       return {
//         ...state,
//         showCounter: !state.showCounter,
//         // counter: state.counter,
//       };
//     default:
//       return state;
//   }
// };

//3. 创建 Store
// const store = createStore(counterReducer);

//4. 订阅状态变化
// store.subscribe(() => {
//     console.log("State updated:", store.getState());
//   });

//   store.dispatch({ type: "INCREMENT" }); // { counter: 1 }
//   store.dispatch({ type: "INCREMENT" }); // { counter: 2 }
//   store.dispatch({ type: "DECREMENT" }); // { counter: 1 }

//----createSlice

const counterSlice = createSlice({
  name: "counter", //`name` is a required option for createSlice
  initialState: initialCounterState,
  reducers: {
    increment(state) {
      state.counter++;
    },
    decrement(state) {
      state.counter--;
    },
    increase(state, action) {
      state.counter = state.counter + action.payload;
    },
    toggle(state) {
      state.showCounter = !state.showCounter;
    },
  },
});

export default counterSlice.reducer;
export const counterActions = counterSlice.actions;
