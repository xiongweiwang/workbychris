import PropTypes from "prop-types";
function Header({ text = "Hello default Header" }) {
  const headerStyle = {
    backgroundColor: "rgba(0, 0, 0, 0.4)", // Corrected to "backgroundColor"
    color: "#ff6a95", // Corrected to "color"
  };
  return (
    <header style={headerStyle}>
      <div className="container">
        <h2>{text}</h2>
      </div>
    </header>
  );
}

Header.propTypes = {
  text: PropTypes.string,
};

export default Header;
