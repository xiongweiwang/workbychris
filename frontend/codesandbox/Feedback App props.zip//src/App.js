import React, { useState } from "react";
import "./styles.css";
import Header from "./components/Header";
import FeedbackData from "./data/FeedbackData";
import FeedbackList from "./components/FeedbackList";
import Feedbackstats from "./components/Feedbackstats";
import FeedbackForm from "./components/FeedbackForm";
import { v4 as uuidv4 } from "uuid";

import {
  BrowserRouter as Router,
  Routes,
  Route,
  NavLink,
} from "react-router-dom";
import AboutPage from "./pages/AboutPage";
import AboutIconLink from "./components/AboutIconLink";
import Card from "./components/shared/Card";
import Post from "./components/Post.jsx";

export default function App() {
  const [feedback, setFeedback] = useState(FeedbackData);
  const deleteFeedback = (id) => {
    if (window.confirm("Are you sure you want to delete?")) {
      setFeedback(feedback.filter((item) => item.id != id));
    }
  };

  const addFeedback = (newFeedback) => {
    newFeedback.id = uuidv4();
    setFeedback([newFeedback, ...feedback]);
  };

  return (
    <Router>
      <div className="container">
        <Routes>
          {/* Default Route */}
          <Route
            exact
            path="/"
            element={
              <>
                <FeedbackForm handleAdd={addFeedback} />
                <Feedbackstats feedback={feedback} />
                <FeedbackList
                  feedback={feedback}
                  handleDelete={deleteFeedback}
                />
              </>
            }
          />
          {/* About Page Route */}
          <Route path="/about" element={<AboutPage />} />
          {/* <Route path="/post/:id/:name" element={<Post />} /> */}
          <Route path="/post/*" element={<Post />} />
          {/* <Route path="/post/" element={<Post />} /> */}
        </Routes>
        <Card>
          <div className="nav">
            <NavLink to="/" activeclassName="active">
              Home
            </NavLink>
            <NavLink to="/about" activeclassName="active">
              About
            </NavLink>

            <NavLink to="/post" activeclassName="active">
              Post
            </NavLink>
            <Routes>
              <Route
                path="/post"
                element={
                  <NavLink to="show" activeclassName="active">
                    Show
                  </NavLink>
                }
              />
            </Routes>
          </div>
        </Card>
        <AboutIconLink />
      </div>
    </Router>
  );
}
