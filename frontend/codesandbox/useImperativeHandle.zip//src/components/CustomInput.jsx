import React, { forwardRef, useRef, useImperativeHandle } from "react";

const CustomInput = forwardRef((props, ref) => {
  const inputRefInner = useRef();

  useImperativeHandle(ref, () => ({
    focus: () => inputRefInner.current.focus(),
    clear: () => (inputRefInner.current.value = ""),
    getValue: () => inputRefInner.current.value,
  }));

  return <input ref={inputRefInner} {...props} />;
});

export default CustomInput;
