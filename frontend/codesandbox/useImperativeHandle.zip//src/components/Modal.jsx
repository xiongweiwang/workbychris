import React, { forwardRef, useImperativeHandle, useState } from "react";

const Modal = forwardRef((props, ref) => {
  const [isOpen, setIsOpen] = useState(false);

  // Expose open and close methods to the parent
  useImperativeHandle(ref, () => ({
    open: () => setIsOpen(true),
    close: () => setIsOpen(false), // Correctly updates state
  }));

  if (!isOpen) return null; // Only render if open

  return (
    <div style={styles.overlay}>
      <div style={styles.modal}>
        <h2>{props.title || "Modal"}</h2>
        <p>{props.children}</p>
        {/* Close button inside the modal */}
        <button onClick={() => setIsOpen(false)}>Close</button>
      </div>
    </div>
  );
});

const styles = {
  overlay: {
    position: "fixed",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  modal: {
    background: "#aaa",
    padding: "20px",
    borderRadius: "8px",
    textAlign: "center",
  },
};

export default Modal;
