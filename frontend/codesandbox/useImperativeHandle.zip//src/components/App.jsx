import React, { useRef } from "react";
import CustomInput from "./CustomInput";
import Modal from "./Modal";

function App() {
  const inputRefApp = useRef();

  const handleFocus = () => inputRefApp.current.focus();
  const handleClear = () => inputRefApp.current.clear();
  const handleGetValue = () =>
    alert(`Value: ${inputRefApp.current.getValue()}`);

  const modalRef = useRef();

  const handleOpen = () => modalRef.current.open(); // Opens the modal
  const handleClose = () => modalRef.current.close(); // Closes the modal

  return (
    <div>
      <CustomInput ref={inputRefApp} placeholder="请输入内容…" />
      <button onClick={handleFocus}>聚焦</button>
      <button onClick={handleClear}>清空</button>
      <button onClick={handleGetValue}>获取值</button>
      <br /> <br /> <br />
      <button onClick={handleOpen}>Open Modal</button>
      <button onClick={handleClose}>Close Modal</button> {/* Works now */}
      <Modal ref={modalRef} title="Reusable Modal">
        This is a reusable modal component!
      </Modal>
    </div>
  );
}

export default App;
