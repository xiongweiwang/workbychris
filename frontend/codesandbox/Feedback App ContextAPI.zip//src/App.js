import Header from "./components/Header";
import FeedbackForm from "./components/FeedbackForm.jsx";
import FeedbackList from "./components/FeedbackList";
import Feedbackstats from "./components/Feedbackstats.jsx";

import { FeedbackProvider } from "./context/FeedbackContext.js";

function APP() {
  return (
    <FeedbackProvider>
      <Header text="Header text" />
      <div className="container">
        <FeedbackForm />
        <Feedbackstats />
        <FeedbackList />
      </div>
    </FeedbackProvider>
  );
}

export default APP;
