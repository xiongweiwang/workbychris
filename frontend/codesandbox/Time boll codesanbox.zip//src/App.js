import "./styles.css";
import TimeSpaceBallGame from "./components/TimeSpaceBallGame";

export default function App() {
  return (
    <div className="App">
      <TimeSpaceBallGame />
    </div>
  );
}
