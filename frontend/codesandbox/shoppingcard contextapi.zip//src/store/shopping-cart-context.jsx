import { createContext, useReducer } from "react";
import { DUMMY_PRODUCTS } from "../dummy-products.js";

export const CartContext = createContext({
  items: [],
  addItemToCart: () => {},
  updateItemQuantity: () => {},
});

function shoppingCartReducer(state, action) {
  if (action.type === "ADD_ITEM") {
    const updateItems = [...state.items];

    const existingCartItemIndex = updateItems.findIndex(
      (cartItem) => cartItem.id === action.payload
    );

    if (existingCartItemIndex !== -1) {
      // Product already exists, update quantity
      updateItems[existingCartItemIndex] = {
        ...updateItems[existingCartItemIndex],
        quantity: updateItems[existingCartItemIndex].quantity + 1,
      };
    } else {
      // Add new product
      const product = DUMMY_PRODUCTS.find(
        (product) => product.id === action.payload
      );
      if (!product) {
        return state; // Return current state if product not found
      }

      updateItems.push({
        id: action.payload,
        name: product.title,
        price: product.price,
        quantity: 1,
      });
    }

    return {
      ...state,
      items: updateItems,
    };
  }

  if (action.type === "UPDATE_ITEM") {
    const updatedItems = [...state.items];
    const updatedItemIndex = updatedItems.findIndex(
      (item) => item.id === action.payload.productId
    );

    if (updatedItemIndex === -1) {
      console.error(
        `Product with id ${action.payload.productId} not found in the cart.`
      );
      return state;
    }

    const updatedItem = {
      ...updatedItems[updatedItemIndex],
    };

    updatedItem.quantity += action.payload.amount;

    if (updatedItem.quantity <= 0) {
      updatedItems.splice(updatedItemIndex, 1); // Remove item if quantity <= 0
    } else {
      updatedItems[updatedItemIndex] = updatedItem;
    }

    return {
      ...state,
      items: updatedItems,
    };
  }

  return state; // Default return current state
}

export default function CartContextProvider({ children }) {
  const [shoppingCartState, shoppingCartDispatch] = useReducer(
    shoppingCartReducer,
    { items: [] }
  );

  function handleAddItemToCart(id) {
    shoppingCartDispatch({
      type: "ADD_ITEM",
      payload: id,
    });
  }

  function handleUpdateCartItemQuantity(productId, amount) {
    if (amount === 0) return;
    shoppingCartDispatch({
      type: "UPDATE_ITEM",
      payload: {
        productId,
        amount,
      },
    });
  }

  const cxtValue = {
    items: shoppingCartState.items,
    addItemToCart: handleAddItemToCart,
    updateItemQuantity: handleUpdateCartItemQuantity,
  };

  return (
    <CartContext.Provider value={cxtValue}>{children}</CartContext.Provider>
  );
}
